chmod +x $MODPATH/service.sh
