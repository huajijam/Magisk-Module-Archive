mount --bind $(dirname "$0")/fake /sys/fs/selinux/enforce
